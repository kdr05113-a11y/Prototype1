# Fit3 GPT Bridge

Galaxy Fit3가 휴대폰 알림을 미러링하는 점을 이용해, ChatGPT Android 앱의 최신 알림을 별도의 **고정 알림**으로 유지하는 Android 앱입니다.

## 동작
1. `NotificationListenerService`가 공식 ChatGPT 앱(`com.openai.chatgpt`) 알림을 감지합니다.
2. 알림의 `BIG_TEXT`/`TEXT`를 추출합니다.
3. `Fit3 GPT Bridge`의 ongoing notification 하나를 같은 ID로 계속 갱신합니다.
4. 새 GPT 알림마다 일반 알림을 한 번 추가로 보내 Fit3 팝업도 유도합니다.
5. 마지막 문구는 SharedPreferences에 저장되어 재부팅 후 다시 표시됩니다.

## 휴대폰 설정
1. 앱 실행 후 **알림 접근 권한**을 허용합니다.
2. Android 13+에서는 앱 알림 권한도 허용합니다.
3. Galaxy Wearable → 밴드 설정 → 알림 → 앱 알림 → **Fit3 GPT Bridge ON**
4. 필요하면 `휴대전화 사용 중에도 알림 표시`를 켭니다.

## 중요한 제한
이 앱은 ChatGPT 대화 내용을 직접 읽는 것이 아니라 **Android 알림에 포함된 미리보기 텍스트**만 읽습니다. 따라서 아주 긴 답변 전체를 Fit3에 보내지는 못합니다.

## 빌드
Android Studio에서 프로젝트 폴더를 열고 `app`을 빌드하거나:

```bash
./gradlew assembleDebug
```

생성 APK: `app/build/outputs/apk/debug/app-debug.apk`

## 개인정보 처리
알림 텍스트는 네트워크로 전송하지 않고 기기 내부 `SharedPreferences`에 마지막 문구만 저장합니다. 앱 자체에는 인터넷 권한도 없습니다.

## ChatGPT 소스 앱
공식 Google Play 앱의 패키지 ID `com.openai.chatgpt`만 수신하도록 고정되어 있습니다.

## Android Studio 없이 APK 만들기 — GitHub Actions

이 프로젝트에는 `.github/workflows/build-apk.yml`이 포함되어 있습니다.

1. GitHub에서 새 저장소를 만듭니다.
2. 이 ZIP의 압축을 푼 전체 내용을 저장소에 업로드합니다. `.github` 폴더도 포함해야 합니다.
3. 저장소의 **Actions** 탭 → **Build Fit3 GPT Bridge APK** → **Run workflow**를 누릅니다.
4. 빌드가 끝나면 해당 실행 화면 아래 **Artifacts**에서 `Fit3GPTBridge-debug-apk`를 받습니다.
5. 압축을 풀어 `app-debug.apk`를 갤럭시에 설치합니다.

이 APK는 Android의 표준 debug key로 자동 서명되므로 테스트/개인 설치용으로 바로 설치할 수 있습니다. Android Studio는 필요하지 않습니다.
