package com.youngjae.fit3gptbridge;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    private EditText manualText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BridgeNotifications.createChannels(this);
        setContentView(buildUi());
        requestNotificationsIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        if (manualText != null) manualText.setText(BridgeNotifications.getLastText(this));
    }

    private View buildUi() {
        int pad = dp(20);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Fit3 GPT Bridge");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("ChatGPT 앱의 새 알림을 잡아 최신 내용을 ‘고정 알림’으로 유지합니다. Galaxy Fit3는 이 앱의 알림을 미러링해 계속 확인할 수 있습니다.");
        desc.setTextSize(16);
        desc.setPadding(0, dp(10), 0, dp(18));
        root.addView(desc);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(status);

        Button access = button("1. 알림 접근 권한 열기");
        access.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            }
        });
        root.addView(access);

        Button notif = button("2. 이 앱 알림 설정 열기");
        notif.setOnClickListener(v -> openOwnNotificationSettings());
        root.addView(notif);

        TextView wearable = new TextView(this);
        wearable.setText("3. Galaxy Wearable → 밴드 설정 → 알림 → 앱 알림에서 ‘Fit3 GPT Bridge’를 켜세요. 가능하면 ‘휴대전화 사용 중에도 알림 표시’도 켜세요.");
        wearable.setTextSize(15);
        wearable.setPadding(0, dp(16), 0, dp(16));
        root.addView(wearable);

        TextView manualLabel = new TextView(this);
        manualLabel.setText("고정해서 볼 문구");
        manualLabel.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(manualLabel);

        manualText = new EditText(this);
        manualText.setMinLines(4);
        manualText.setGravity(android.view.Gravity.TOP);
        manualText.setText(BridgeNotifications.getLastText(this));
        manualText.setHint("예: 형소법 315조: 1호=공무상 증명문서 / 3호=특신상태 문서");
        root.addView(manualText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        Button pin = button("이 문구를 Fit3용 고정 알림으로 표시");
        pin.setOnClickListener(v -> {
            String s = manualText.getText().toString().trim();
            if (TextUtils.isEmpty(s)) return;
            BridgeNotifications.showPersistent(this, "GPT · Fit3 고정", s);
            Toast.makeText(this, "고정 알림을 갱신했습니다.", Toast.LENGTH_SHORT).show();
        });
        root.addView(pin);

        Button test = button("테스트 팝업 보내기");
        test.setOnClickListener(v -> {
            BridgeNotifications.showPulse(this, "GPT 테스트", "Fit3에 이 문구가 보이면 연결 성공입니다.");
            Toast.makeText(this, "테스트 알림을 보냈습니다.", Toast.LENGTH_SHORT).show();
        });
        root.addView(test);

        TextView note = new TextView(this);
        note.setText("동작 방식: ChatGPT에서 알림이 오면 그 알림에 실제로 포함된 텍스트를 가져옵니다. 긴 GPT 답변 전체가 아니라 Android 알림 미리보기 범위까지만 전달될 수 있습니다.");
        note.setTextSize(13);
        note.setPadding(0, dp(18), 0, dp(20));
        root.addView(note);

        return scroll;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    private void refreshStatus() {
        boolean listener = isNotificationServiceEnabled();
        boolean post = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        status.setText("알림 접근: " + (listener ? "허용됨 ✓" : "필요함") +
                "\n알림 표시: " + (post ? "허용됨 ✓" : "필요함"));
    }

    private boolean isNotificationServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        ComponentName me = new ComponentName(this, GptNotificationListener.class);
        return enabled.contains(me.flattenToString());
    }

    private void openOwnNotificationSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(i);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
