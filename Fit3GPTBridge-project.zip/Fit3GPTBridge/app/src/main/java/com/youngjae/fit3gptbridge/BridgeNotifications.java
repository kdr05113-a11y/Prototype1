package com.youngjae.fit3gptbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class BridgeNotifications {
    public static final String STATUS_CHANNEL = "fit3_gpt_status";
    public static final String PULSE_CHANNEL = "fit3_gpt_new";
    public static final int STATUS_ID = 3001;
    public static final int PULSE_ID = 3002;
    private static final String PREFS = "bridge_prefs";
    private static final String KEY_TITLE = "last_title";
    private static final String KEY_TEXT = "last_text";

    private BridgeNotifications() {}

    public static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);

        NotificationChannel status = new NotificationChannel(
                STATUS_CHANNEL,
                "Fit3 고정 GPT",
                NotificationManager.IMPORTANCE_DEFAULT);
        status.setDescription("Galaxy Fit3에서 계속 확인할 최신 GPT 내용");
        status.setSound(null, null);
        status.enableVibration(false);
        status.setShowBadge(false);
        nm.createNotificationChannel(status);

        NotificationChannel pulse = new NotificationChannel(
                PULSE_CHANNEL,
                "새 GPT 팝업",
                NotificationManager.IMPORTANCE_DEFAULT);
        pulse.setDescription("새 ChatGPT 알림이 들어올 때 Fit3로 전달할 알림");
        pulse.setSound(null, null);
        pulse.enableVibration(true);
        nm.createNotificationChannel(pulse);
    }

    public static void saveLatest(Context context, String title, String text) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_TITLE, title == null ? "ChatGPT" : title)
                .putString(KEY_TEXT, text == null ? "" : text)
                .apply();
    }

    public static String getLastText(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_TEXT, "아직 받은 GPT 알림이 없습니다.");
    }

    public static String getLastTitle(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_TITLE, "ChatGPT");
    }

    public static void showPersistent(Context context, String title, String text) {
        createChannels(context);
        saveLatest(context, title, text);
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        nm.notify(STATUS_ID, build(context, STATUS_CHANNEL, title, text, true, false));
    }

    public static void showPulse(Context context, String title, String text) {
        createChannels(context);
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        nm.notify(PULSE_ID, build(context, PULSE_CHANNEL, title, text, false, true));
    }

    public static void restore(Context context) {
        showPersistent(context, getLastTitle(context), getLastText(context));
    }

    private static Notification build(Context context, String channel, String title, String text,
                                      boolean ongoing, boolean autoCancel) {
        Intent launch = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                0,
                launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, channel)
                : new Notification.Builder(context);

        return b.setSmallIcon(com.youngjae.fit3gptbridge.R.drawable.ic_bridge)
                .setContentTitle(title == null || title.trim().isEmpty() ? "ChatGPT" : title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(contentIntent)
                .setOngoing(ongoing)
                .setAutoCancel(autoCancel)
                .setOnlyAlertOnce(ongoing)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setWhen(System.currentTimeMillis())
                .build();
    }
}
