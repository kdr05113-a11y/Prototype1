package com.youngjae.fit3gptbridge;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

public class GptNotificationListener extends NotificationListenerService {
    private static final String CHATGPT_PACKAGE = "com.openai.chatgpt";

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        BridgeNotifications.restore(this);
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !CHATGPT_PACKAGE.equals(sbn.getPackageName())) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;

        Bundle e = n.extras;
        String title = firstNonBlank(
                asText(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)),
                asText(e.getCharSequence(Notification.EXTRA_TITLE)),
                "ChatGPT");

        String text = firstNonBlank(
                extractMessagingStyle(e),
                asText(e.getCharSequence(Notification.EXTRA_BIG_TEXT)),
                joinLines(e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)),
                asText(e.getCharSequence(Notification.EXTRA_TEXT)),
                asText(e.getCharSequence(Notification.EXTRA_SUB_TEXT)));

        text = clean(text);
        if (TextUtils.isEmpty(text)) return;

        BridgeNotifications.showPersistent(this, title, text);
        BridgeNotifications.showPulse(this, "GPT 새 알림", text);
    }

    private static String extractMessagingStyle(Bundle extras) {
        try {
            Parcelable[] raw = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (raw == null || raw.length == 0) return "";
            Notification.MessagingStyle.Message[] messages =
                    Notification.MessagingStyle.Message.getMessagesFromBundleArray(raw);
            if (messages == null || messages.length == 0) return "";
            CharSequence last = messages[messages.length - 1].getText();
            return asText(last);
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String joinLines(CharSequence[] lines) {
        if (lines == null || lines.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (CharSequence line : lines) {
            if (line == null) continue;
            String s = line.toString().trim();
            if (s.isEmpty()) continue;
            if (sb.length() > 0) sb.append(" · ");
            sb.append(s);
        }
        return sb.toString();
    }

    private static String asText(CharSequence value) {
        return value == null ? "" : value.toString();
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) {
            if (v != null && !v.trim().isEmpty()) return v.trim();
        }
        return "";
    }

    private static String clean(String value) {
        if (value == null) return "";
        String s = value.replaceAll("\\s+", " ").trim();
        if (s.length() > 900) s = s.substring(0, 900) + "…";
        return s;
    }
}
